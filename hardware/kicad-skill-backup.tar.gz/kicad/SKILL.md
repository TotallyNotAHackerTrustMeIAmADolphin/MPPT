---
name: kicad
description: Advanced KiCad PCB and Schematic engineering. Use when working with .kicad_sch or .kicad_pcb files to perform DRC/ERC audits, manage footprints, analyze nets, or generate manufacturing files (Gerbers/BOM).
---

# KiCad Engineering Skill

This skill enables advanced interaction with KiCad electronic design automation files. It leverages the KiCad CLI and bundled automation logic to provide professional hardware engineering support.

## Core Capabilities
- **Schematic Audits**: Automated Electrical Rules Check (ERC) and floating net detection.
- **PCB Audits**: Automated Design Rules Check (DRC) for clearance, track width, and connectivity.
- **Manufacturing**: Automated generation of Gerbers, Drill files, and Bill of Materials (BOM).
- **Netlist Management**: Verification of schematic-to-PCB synchronization.
- **Physical Analysis**: Calculation of trace current capacity and thermal via verification.

## Core Mandates
- **S-Expression Precision**: KiCad v6+ files are S-expressions. Use the KiCad CLI (`kicad-cli`) for all structural audits and exports.
- **No Manual Designator Changes**: Never re-assign designators (e.g., R1 -> R2) manually; always use the KiCad annotation engine via the GUI or CLI if available.
- **Safety First**: When analyzing power stages (like the Buck-Boost in openMPPT), always prioritize trace width and clearance audits for high-current paths.

## Primary Workflows

### 1. Running Audits (DRC/ERC)
Always run audits before proposing board changes or finalizing a release.
- **Schematic (ERC)**: `kicad-cli sch erc --exit-code-violations`
- **PCB (DRC)**: `kicad-cli pcb drc --exit-code-violations`
- **Action**: Parse the output and provide a "Red/Yellow/Green" status report to the user.

### 2. Exporting Manufacturing Files
Use this workflow when the user says "prepare for manufacturing" or "generate Gerbers."
- **Gerbers**: `kicad-cli pcb export gerber --output gerbers/`
- **Drill Files**: `kicad-cli pcb export drill --output gerbers/`
- **BOM**: `kicad-cli sch export bom --output bom.csv`

### 3. Net & Trace Analysis
To analyze specific nets (e.g., `Vin`, `GND`, `PHASE`):
- Use `grep_search` to find the net definition in the `.kicad_pcb` file.
- Look for `(segment (start ...) (end ...) (width <VALUE>) (layer ...) (net <ID>))` to calculate total resistance or current capacity.

## Integration with pcb-mcp
This skill includes bundled logic from the `pcb-mcp` project (located in `assets/pcb-mcp`). If a Python environment with `kicad-python` is available, these scripts can be used for advanced placement and routing reasoning.

---
*Note: This skill assumes `kicad-cli` (v7+) is installed on the system path.*
